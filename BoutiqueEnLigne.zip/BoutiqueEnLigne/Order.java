
public class Order implements Cart {
    private Product[] products;
    private int size;

    public Order(int capacity) {
        this.products = new Product[capacity];
        this.size = 0;
    }

    
    public void addProduct(Product product) {
        if (size < products.length) {
            products[size] = product;
            size++;
        }
    }

    public boolean removeProduct(Product product) {
        for (int i = 0; i < size; i++) {
            if (products[i].equals(product)) {
                // Décalage des produits
                for (int j = i; j < size - 1; j++) {
                    products[j] = products[j + 1];
                }
                size--;
                return true;
            }
        }
        return false;
    }
}