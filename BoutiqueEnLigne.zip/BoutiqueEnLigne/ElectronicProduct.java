

public class ElectronicProduct extends Product {
    
    Double power ;
//Constructeur
    public ElectronicProduct(String name, Double price, String reference, Double power) {
        super(name, price, reference);
        this.power = power;
    }
//Get - Set
    public Double getPower() {
        return power;
    }

    public void setPower(Double power) {
        this.power = power;
    }
//Methode
 /* 
@Override
    public String getDescription() {
return getDescription()+ "ElectronicProduct  power=" + power+"]" ;
    }*/
    @Override
    public String getDescription() {
return "Product =  Name : " + name+ " Price  : " + price+"  Reference  : " + reference+" Power : " + power+"" ;
}}