public class App {
    public static void main(String[] args) {

       ElectronicProduct electroproduct = new ElectronicProduct("p1 ",15.00 ,"007",70.00);
        ClothingProduct vetement = new ClothingProduct("p2", 20.00, "008", "L");
        BookProduct livre = new BookProduct("Atomic Habits", 20.00, "009", "James Clear");
       System.out.println(electroproduct.getDescription());
       System.out.println(vetement.getDescription());
       System.out.println(livre.getDescription());
    
    }
}
